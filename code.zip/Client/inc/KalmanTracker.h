#ifndef KALMANTRACKER_H_
#define KALMANTRACKER_H_ KALMANTRACKER_H_

#include"IFusionInterface.h"
#include"matrix.h"
#include "JSONFileLogger.h"
#include"HungarianAlgorithm.h"

class KalmanTracker : public IFusionInterface
{  
  public:
    
  KalmanTracker();

  ~KalmanTracker();

  void read_state(const Object &object);
   

  void read_covariance(const Object & object);

  void write_object(Object & object);

 
  void predict(const uint64_t timestamp) ;
   
  void createNewObject(const SensorObject &sensorObject);
  


  bool associate(const SensorObject &sensorObject,
                         uint8_t &associatedObjectIndex);
    
 
  void update(const SensorObject &sensorObject,
                      const uint8_t associatedObjectIndex) ;
     
      


  void findMinimum(std::vector<std::vector<float>> &associationMatrix);
  void doUpdate(const SensorObjectList &sensorObjectList) ;

  void logwriter(const SensorObjectList &sensorObjectList) ;


private:
     Matrix x_;

    // state covariance matrix
    Matrix P_;

    // state transistion matrix
    Matrix F_;

    // process covariance matrix
    Matrix Q_;

    // measurement matrix
    Matrix H_;  

    // measurement covariance matrix
    Matrix R_;

    Matrix Ht;

    bool is_initialized_;
    
    float threshold_gating;

    std::vector<float> _costMatrix;

    std::vector<std::pair<int,int>> associationArray;


};




#endif
