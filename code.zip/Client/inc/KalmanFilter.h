#ifndef KALMANFILTER_H_
#define KALMANFILTER_H_ KALMANFILTER_H_

#include"matrix.h"

class KalmanFilter{
public:
 KalmanFilter();

 ~KalmanFilter();


private:
     Matrix x_;

    // state covariance matrix
    Matrix P_;

    // state transistion matrix
    Matrix F_;

    // process covariance matrix
    Matrix Q_;

    // measurement matrix
    Matrix H_;  

    // measurement covariance matrix
    Matrix R_;


};

#endif